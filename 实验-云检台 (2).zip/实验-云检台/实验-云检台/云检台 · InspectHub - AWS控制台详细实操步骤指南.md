# 云检台 · InspectHub - AWS控制台详细实操步骤指南

> **事实与风险提示：**
>
> - AWS 控制台的 UI 界面会持续更新，强行记忆“按钮在左边还是右边”存在因界面改版导致操作失败的风险。  
> - 建议在操作时以“搜索服务名称 -> 寻找 Create/新建 按钮”的逻辑为主。  
> - 此外，本指南涉及的 NAT 网关是产生隐性成本的变量，在完成拉取二进制任务后需密切关注流量费用。  

![image-20260902154517344](images/image-20260902154517344.png)

## 第一阶段：网络与安全基座

### 1. 创建 VPC 与网络拓扑

- 确保右上角区域选择为 us-east-1 (N. Virginia)。  
- 在顶部搜索框输入 VPC，点击进入 VPC Dashboard。  
- 点击显眼的橙色按钮 Create VPC。  
- 选择 VPC and more（这能一键创建子网和路由表）。  
- Name tag auto-generation：输入 inspecthub。  
- Number of Availability Zones (AZs)：选择 2。  
- Number of public subnets：选择 2。  
- Number of private subnets：选择 2。  
- NAT gateways：选择 1 AZ（成本考量，只需一个即可让私有子网出网）。  
- VPC endpoints：选择 S3 Gateway（用于内网免费访问 S3 归档桶）。  
- 点击右下角 Create VPC，等待所有资源打勾创建完成。  

### 2. 创建并串联安全组 (Security Groups)

- 应用与数据库之间的安全组引用使用安全组 ID，不使用 `0.0.0.0/0`；ALB 的 80 端口按题目要求允许公网访问。

- 在顶部搜索 EC2，进入 EC2 面板。  

- 左侧导航栏下拉找到 Security Groups。  

- **创建 ALB 安全组 (alb-sg)**：点击 Create security group。名字填 alb-sg，VPC 选刚才创建的 inspecthub-vpc。Inbound rules 

  ```shell
  添加入站规则：类型 HTTP (80)，Source 选 Anywhere-IPv4 (0.0.0.0/0)。创建。
  ```

- **创建应用安全组 (app-sg)**：点击 Create security group。名字填 app-sg，VPC 选 inspecthub-vpc。Inbound rules 

  ```shell
  添加规则：类型 Custom TCP，端口 8080，Source 处点击搜索框，下拉选择刚才建好的 alb-sg 的 ID (sg-xxxx)。创建。 
  ```

- ##### 创建baolei安全组

  ```shell
  添加规则：
  SSH 22Source = 你的公网 IP/32
  ```
  
- **创建 RDS 安全组 (rds-sg)**：点击 Create security group。名字填 rds-sg，VPC 选 inspecthub-vpc。Inbound rules 

  ```shell
  添加规则：类型 
  MySQL/Aurora   TCP   3306  Source 选 app-sg 的 ID。创建。
  MySQL/Aurora   TCP   3306  Source = baolei-sg
  ```

  | 安全组        | 绑定资源                  | 入站协议  | 端口     | 来源（Source）     | 用途                                      |
  | ------------- | ------------------------- | --------- | -------- | ------------------ | ----------------------------------------- |
  | **alb-sg**    | Application Load Balancer | HTTP/TCP  | **80**   | `0.0.0.0/0`        | 允许公网访问 ALB                          |
  | **app-sg**    | ASG 中的应用 EC2          | TCP       | **8080** | **alb-sg**         | 仅允许 ALB 访问应用                       |
  | **rds-sg**    | RDS MySQL                 | MySQL/TCP | **3306** | **app-sg**         | 允许应用访问数据库                        |
  | **rds-sg**    | RDS MySQL                 | MySQL/TCP | **3306** | **baolei-sg**      | 允许堡垒机访问数据库，便于你手工测试/建表 |
  | **baolei-sg** | 堡垒机 EC2                | SSH/TCP   | **22**   | **你的公网 IP/32** | 仅允许你的电脑 SSH 登录堡垒机             |

## 第二阶段：数据与归档存储

### 1. 创建 RDS MySQL 实例

- 文档明确要求不能用 Aurora，且必须在私有子网，不对公网开放。  

- ```shell
  RDS → Subnet groups
  ↓
  Create DB subnet group
  ↓
  VPC = inspecthub-vpc
  ↓
  Private Subnet AZ1
  Private Subnet AZ2
  ```

  

- 搜索 RDS 进入控制台，点击 Create database。  

  ```
  - 选择 Standard create。  
  - Engine options 选择 MySQL。  
  - Templates 选择 Free tier 或 Dev/Test（控制成本）。  
  - DB instance identifier：inspecthub-db。  
  - Master username：输入 admin（记住此变量，后续应用需用到）。  
  - Master password：输入强密码并记录（后续需用到）。  
  - Connectivity：VPC 选择 inspecthub-vpc。
  Availability Zones:
  Private Subnet AZ1
  Private Subnet AZ2
  
  DB Subnet Group：
  inspecthub-db-subnet-group
  - Public access 必须选 No。  
  - VPC security group：选择 Choose existing，并选中 rds-sg（移除 default）。  
  - Additional configuration：展开此项，Initial database name 填入 inspecthub。  
  - 点击最下方 Create database
  ```
  
  

### 2. 创建 S3 归档桶

- 搜索 S3 进入控制台，点击 Create bucket。  

  ```
  Block all public access：保持开启
  Object Ownership：Bucket owner enforced
  不要创建公开 Bucket Policy
  EC2 通过 IAM Role + S3 Gateway Endpoint 访问
  ```

- 创建存储桶目录/photos

  ```
   inspecthub-archive-629720698532
   /photos
  ```

## 第三阶段：堡垒机及其渗透

### 1.创建 堡垒机

- 搜索 EC2，左侧菜单选择 **Instances (实例)**，点击右上角橙色按钮 **Launch instances (启动新实例)**。

  Name 填入：inspecthub-bastion。
- Template name：**inspecthub-template**。  
- AMI：Amazon Linux 2023。  
- Instance type：选择 t2.micro 或 t3.micro。  
- Network settings：VPC 选择 `inspecthub-vpc`，**子网必须选择公有子网 (Public Subnet)**，并**开启“自动分配公有 IPv4 地址”**。Security groups 选择 **baolei安全组**。
- Advanced details：
  - IAM instance profile：选择预置的 **InspectHubInstanceRole**。

-    安全组选择baolei安全组

### 2.连接堡垒机

#### 通过windows终端ssh连接堡垒机

```powershell
ssh -i C:\Users\Administrator\Downloads\你的key文件.pem  ec2-user@堡垒机Ip地址
```

#### 配置环境变量

```shell
export DB_HOST="你的RDS端点地址" 
export DB_USER="admin"
export DB_PASSWORD="你的数据库密码"
export DB_NAME="inspecthub"
export PHOTO_DIR="/var/lib/inspecthub/photos"
sudo mkdir -p $PHOTO_DIR
sudo chown -R ec2-user:ec2-user /var/lib/inspecthub
sudo dnf install -y lsof
```

### 3.连接数据库

**连接 RDS MySQL 数据库**

在你的 EC2 终端（或堡垒机）中，使用 MySQL 客户端执行以下命令。请将 `<你的RDS端点>` 替换为真实的 Endpoint 地址。

```shell
mysql -h <你的RDS端点> -P 3306 -u admin -p inspecthub
```

**创建 inspections 表格 (SQL 语句)**  

```sql
CREATE TABLE inspections (
    inspection_id VARCHAR(255) PRIMARY KEY,
    device_id VARCHAR(255) NOT NULL,
    result VARCHAR(10) NOT NULL,
    photo_name VARCHAR(255),
    submitted_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_device_id (device_id)
);
```

**表结构设计说明**

- **主键**：`inspection_id` 设为字符串类型的 `PRIMARY KEY`。  
- **非空限制**：`device_id` 设为 `NOT NULL`，并且根据题目“需按它查询”的要求，在底部为其添加了普通索引 `INDEX idx_device_id`，以提升查询性能。  
- **结果枚举**：`result` 字段保留为字符串，应用会写入 `ok`、`warn` 或 `fault`。  
- **时间戳**：`submitted_at` 使用 `TIMESTAMP` 类型。  



### 4.下载应用

```shell
wget [二进制下载链接] -O /home/ec2-user/inspecthub-app
chmod +x /home/ec2-user/inspecthub-app
```

##### 没有应用则通过scp进行传输

> 注意：scp传输需要用到Key密钥

```powershell
scp -r -i "C:\Users\Administrator\Downloads\你的密钥.pem" "C:\Users\Administrator\Desktop\inspecthub-app" ec2-user@你的虚拟机Ip地址:~
```

#### 归档清理守护进程（核心逻辑防截断）

> 注意填写桶名，账号id

```shell
cat << 'EOF' > /home/ec2-user/archiver.sh
#!/bin/bash
BUCKET="s3://inspecthub-archive-629720698532/photos/"
while true; do
  for file in /var/lib/inspecthub/photos/*.png; do
    if [ -f "$file" ]; then
      # 使用 lsof 检查文件是否仍在被写入
      if ! lsof "$file" > /dev/null; then
        aws s3 cp "$file" "$BUCKET"
        if [ $? -eq 0 ]; then
          rm "$file"
        fi
      fi
    fi
  done
  sleep 5
done
EOF
```

### 创建下线数据保护脚本 (lifecycle-hook.sh)

```shell
cat << 'EOF' > /home/ec2-user/lifecycle-hook.sh
#!/bin/bash

T=$(curl -sX PUT http://169.254.169.254/latest/api/token \
  -H "X-aws-ec2-metadata-token-ttl-seconds: 600")
ID=$(curl -s -H "X-aws-ec2-metadata-token: $T" \
  http://169.254.169.254/latest/meta-data/instance-id)

[ -z "$ID" ] && exit 1

while true; do
    ST=$(aws autoscaling describe-auto-scaling-instances \
      --instance-ids "$ID" \
      --region us-east-1 \
      --query "AutoScalingInstances[0].LifecycleState" \
      --output text)

    if [ "$ST" = "Terminating:Wait" ]; then
        aws s3 sync /var/lib/inspecthub/photos/ \
          s3://inspecthub-archive-629720698532/photos/ || exit 1

        aws autoscaling complete-lifecycle-action \
          --lifecycle-hook-name InspectHub-Termination-Hook \
          --auto-scaling-group-name inspecthub-asg \
          --lifecycle-action-result CONTINUE \
          --instance-id "$ID" \
          --region us-east-1 || exit 1

        break
    fi

    sleep 10
done
EOF

chmod +x /home/ec2-user/lifecycle-hook.sh
```



### 6.附加权限，测试连通性并启动服务

```shell
# 赋予所有脚本执行权限
chmod +x /home/ec2-user/inspecthub-app
chmod +x /home/ec2-user/archiver.sh
chmod +x /home/ec2-user/lifecycle-hook.sh

# 在堡垒机后台挂载测试三个程序
nohup /home/ec2-user/inspecthub-app > /home/ec2-user/app.log 2>&1 &
nohup /home/ec2-user/archiver.sh > /home/ec2-user/archiver.log 2>&1 &
```

**测试 S3 存储桶连接与权限**

- 列出桶内文件（验证读权限与网络连通性）：

  ```shell
  aws s3 ls s3://inspecthub-archive-629720698532/
  ```

- 测试上传一个空文件（验证写权限）：

  ```shell
  touch test-auth.txt
  aws s3 cp test-auth.txt s3://inspecthub-archive-629720698532/
  ```

**检查应用进程/服务是否运行**

- 针对使用 `nohup` 手动挂载在后台的进程：

  ```shell
  ps aux | grep inspecthub-app
  ```

**检查端口是否开启与监听**

- 查看系统底层 8080 端口是否被成功占用并处于 LISTEN 状态：

  ```shell
  sudo ss -tulnp | grep 8080
  ```

  *(或者使用 `sudo netstat -tulnp | grep 8080`)*

- 在机器内部直接发起 HTTP 拨测（最稳妥的最终验证方式）：

  ```shell
  curl -I http://localhost:8080/healthcheck
  ```

  *(如果返回 `HTTP/1.1 200 OK`，说明程序不仅端口通了，内部逻辑也正常运转)*
  
  #### 验证之后关闭服务
  
  ```shell
  pkill -f inspecthub-app
  pkill -f archiver.sh
  ```
  
  ##### 然后检查：
  
  ```shell
  ps aux | grep -E "inspecthub-app|archiver.sh"
  ```
  
  > 确认 `lifecycle-hook.sh` 未运行
  
  ##### 确认没有运行中的进程，再制作 AMI。
  
  ### **4. 制作自定义 AMI**
  
  测试全部通过后，回到 EC2 实例列表。
  
  - 选中这台堡垒机，点击右上角 **操作 (Actions) -> 映像和模板 (Image and templates) -> 创建映像 (Create image)**。
  - 映像名称填入：`inspecthub-custom-ami`。
  - 点击创建，等待 AMI 状态变为 Available（这期间实例会短暂重启）。
  - **注意：镜像创建完成后，即可将这台带有公网 IP 的堡垒机“终止(Terminate)”，消除安全隐患并节省成本。**

## 第四阶段：启动模板与自定义脚本

### 创建 Launch Template

> 注意IAM instance profile：选择预置的 InspectHubInstanceRole。  

- 搜索 EC2，左侧菜单选择 Launch Templates，点击 Create launch template。  
- Template name：inspecthub-template。  
- AMI：选择 **My AMIs (我的 AMI)** 标签页，选中刚刚制作的 `inspecthub-custom-ami`。
- Instance type：选择 t2.micro 或 t3.micro。  
- Network settings：Security groups 选择 app-sg。
- 关闭自动分配公网Ip  
- Auto-assign Public IP：Disable
- Advanced details：
  - IAM instance profile：选择预置的 InspectHubInstanceRole。  
  - User data：这是核心逻辑。  

```shell
#!/bin/bash

# 确保图片目录的从属权限正确（防止打包 AMI 时权限错乱）
sudo chown -R ec2-user:ec2-user /var/lib/inspecthub

# 切换为 ec2-user 身份，注入环境变量并唤醒预埋的应用与脚本
su - ec2-user -c '
export DB_HOST="你的数据库端点" 
export DB_USER="admin"
export DB_PASSWORD="数据库密码"
export DB_NAME="inspecthub"
export PHOTO_DIR="/var/lib/inspecthub/photos"
sudo mkdir -p $PHOTO_DIR
# 后台启动应用
nohup /home/ec2-user/inspecthub-app > /home/ec2-user/app.log 2>&1 &

# 后台启动归档清理脚本
nohup /home/ec2-user/archiver.sh > /home/ec2-user/archiver.log 2>&1 &
# 3. 启动生命周期缩容监听
nohup /home/ec2-user/lifecycle-hook.sh > /home/ec2-user/hook.log 2>&1 &
'
```

- 填写完毕后点击 Create launch template。  

## 第五阶段：应用上线与对外入口

### 1. 创建目标组 (Target Group)

> 注意目标组的端口设置为8080

- ```shell
  - 在 EC2 面板左侧找到 Target Groups，点击 Create target group。  
  - Choose a target type：选择 Instances。  
  - Target group name：inspecthub-tg。  
  - Protocol：HTTP，Port：8080。  
  - VPC：选择 inspecthub-vpc。  
  - Health checks：Health check path 必须明确改为 `/healthcheck`。  
  - 点击 Next，不用选任何实例，直接点击 Create target group。
  ```

    

### 2. 创建应用负载均衡器 (ALB)

- ```shell
  - 在 EC2 面板左侧找到 Load Balancers，点击 Create load balancer，选择 Application Load Balancer。  
  - Name：inspecthub-alb。  
  - Scheme：Internet-facing。  
  - Network mapping：选择 inspecthub-vpc，勾选两个公有子网 (Public Subnets)。  
  - Security groups：选择 alb-sg（移除 default）。  
  - Listeners and routing：Protocol HTTP，Port 80，Default action 转发到 inspecthub-tg。  
  - 点击 Create load balancer。  
  ```

  

## 第六阶段：弹性伸缩与下线保护

### 创建 Auto Scaling 组 (ASG)

> 注意：子网这里选择私有子网

- ```shell
  - 在 EC2 面板左侧找到 Auto Scaling Groups，点击 Create Auto Scaling group。  
  - Name：inspecthub-asg。  
  - Launch template：选择刚才创建的 inspecthub-template。  
  - Network：VPC 选择 inspecthub-vpc，子网选择两个私有子网 (Private Subnets)。  
  - Load balancing：选择 Attach to an existing load balancer，并选择你的目标组 inspecthub-tg。  
  - Group size：Desired=2, Min=2, Max=4。  
  - Scaling policies：配置基于 CPU 使用率（例如 50%）的目标跟踪策略。  
  - 完成创建。  
  ```

  > 创建 ASG 后，禁止进行缩容/终止测试；必须先完成 Lifecycle Hook 创建并确认其已生效
  >
  
  ## 第七阶段：配置下线数据保护 (生命周期挂钩)
  
  为了确保实例缩容（终止）时未归档的照片不丢失：
  
  ● 在新建的 ASG 的 ***\*实例管理 (Instance management)\**** 选项卡中，向下滚动找到 ***\*生命周期挂钩 (Lifecycle hooks)\****。
  
  ● 点击 ***\*创建生命周期挂钩 (Create lifecycle hook)\****。
  
  ● ***\*生命周期挂钩名称 (Lifecycle hook name)\****: InspectHub-Termination-Hook。
  
  ● ***\*生命周期转换 (Lifecycle transition)\****: 选择 ***\*实例终止 (Instance terminate)\****。
  
  ● ***\*检测信号超时 (Heartbeat timeout)\****: 300 秒 (给予实例 5 分钟时间完成最后的数据上传)。
  
  ● 默认结果 (Default result): 选择 ***\*放弃 (ABANDON)\**** 或 ***\*继续 (CONTINUE)\****，配合 InspectHubAutomationRole 使用。

> **严重风险提醒**
>
> - 控制台 ASG 创建完成后，默认不会保护未上传的照片。  
> - 你必须回到 ASG 面板的 Instance management 选项卡，添加 Lifecycle hooks。  
> - 当触发 `autoscaling:EC2_INSTANCE_TERMINATING` 动作时，实例需通过预先利用 InspectHubAutomationRole 写入的内部脚本执行最后一次强制上传，随后利用 AWS CLI 发送 `complete-lifecycle-action` API 允许关机，否则强制缩容将永久丢失数据并导致扣分。  